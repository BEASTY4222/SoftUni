﻿namespace BookVerse.ViewModels
{
    public class BookDetailsViewModel
    {
        
    }
}
