﻿namespace BookVerse.ViewModels
{
    public class BookMyBooksViewModel
    {
        
    }
}
