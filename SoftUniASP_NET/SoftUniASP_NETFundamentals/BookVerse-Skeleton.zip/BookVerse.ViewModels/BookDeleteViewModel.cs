﻿namespace BookVerse.ViewModels
{
    public class BookDeleteViewModel
    {
        
    }
}
