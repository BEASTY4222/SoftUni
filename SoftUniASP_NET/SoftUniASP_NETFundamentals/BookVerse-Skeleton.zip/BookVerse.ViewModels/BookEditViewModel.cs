﻿using System.ComponentModel.DataAnnotations;
using BookVerse.GCommon;

namespace BookVerse.ViewModels
{
    public class BookEditViewModel
    {
        
    }
}
