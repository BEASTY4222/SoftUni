﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookVerse.DataModels
{
    public class UserBook
    {
        public string UserId { get; set; } = null!;
        public IdentityUser User { get; set; } = null!;

        public int BookId { get; set; }
        public Book Book { get; set; } = null!;
    }
}
